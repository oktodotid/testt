<?php

return [
    'app_info' => [
        'api_id' => 23793724,
        'api_hash' => '016c55a5a216025cde3f9184718fff70',
    ],
    'logger' => [
        'logger' => 0,
    ],
    'print_update' => true,
];

